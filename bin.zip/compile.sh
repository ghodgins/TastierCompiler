mono bin/tcc.exe test/Programs/TernaryTest.TAS test.asm
tasm test.asm test.bc
